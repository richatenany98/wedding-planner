var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/index.ts
import "dotenv/config";
import express2 from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import session from "express-session";
import multer from "multer";
import path3 from "path";
import fs2 from "fs";

// server/routes.ts
import { createServer } from "http";

// server/storage.ts
import "dotenv/config";

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  budgetItems: () => budgetItems,
  events: () => events,
  guests: () => guests,
  insertBudgetItemSchema: () => insertBudgetItemSchema,
  insertEventSchema: () => insertEventSchema,
  insertGuestSchema: () => insertGuestSchema,
  insertTaskSchema: () => insertTaskSchema,
  insertUserSchema: () => insertUserSchema,
  insertVendorSchema: () => insertVendorSchema,
  insertWeddingProfileSchema: () => insertWeddingProfileSchema,
  tasks: () => tasks,
  users: () => users,
  vendors: () => vendors,
  weddingProfiles: () => weddingProfiles
});
import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
var users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull(),
  name: text("name").notNull(),
  weddingProfileId: integer("wedding_profile_id")
});
var weddingProfiles = pgTable("wedding_profiles", {
  id: serial("id").primaryKey(),
  brideName: text("bride_name").notNull(),
  groomName: text("groom_name").notNull(),
  weddingStartDate: text("wedding_start_date").notNull(),
  weddingEndDate: text("wedding_end_date").notNull(),
  venue: text("venue").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  guestCount: integer("guest_count").notNull(),
  budget: integer("budget").notNull(),
  functions: text("functions").array().notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  isComplete: boolean("is_complete").default(false)
});
var events = pgTable("events", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  date: text("date").notNull(),
  time: text("time").notNull(),
  location: text("location").notNull(),
  progress: integer("progress").default(0),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
  guestCount: integer("guest_count").default(0),
  weddingProfileId: integer("wedding_profile_id").notNull()
});
var guests = pgTable("guests", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  side: text("side").notNull(),
  rsvpStatus: text("rsvp_status").default("pending"),
  weddingProfileId: integer("wedding_profile_id").notNull()
});
var tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  status: text("status").notNull().default("todo"),
  assignedTo: text("assigned_to").notNull(),
  dueDate: text("due_date"),
  eventId: integer("event_id"),
  weddingProfileId: integer("wedding_profile_id")
});
var budgetItems = pgTable("budget_items", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(),
  vendor: text("vendor").notNull(),
  description: text("description"),
  estimatedAmount: integer("estimated_amount").notNull(),
  actualAmount: integer("actual_amount").default(0),
  paidAmount: integer("paid_amount").default(0),
  status: text("status").notNull().default("pending"),
  paidBy: text("paid_by"),
  // 'bride', 'groom', 'both', 'family'
  eventId: integer("event_id"),
  weddingProfileId: integer("wedding_profile_id")
});
var vendors = pgTable("vendors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  contact: text("contact"),
  email: text("email"),
  phone: text("phone"),
  address: text("address"),
  website: text("website"),
  contractUrl: text("contract_url"),
  notes: text("notes"),
  totalPrice: integer("total_price"),
  securityDeposit: integer("security_deposit"),
  paidBy: text("paid_by"),
  // 'bride', 'groom', 'both', 'family'
  weddingProfileId: integer("wedding_profile_id")
});
var insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
  name: true
}).extend({
  weddingProfileId: z.number().optional()
});
var insertWeddingProfileSchema = createInsertSchema(weddingProfiles).pick({
  brideName: true,
  groomName: true,
  weddingStartDate: true,
  weddingEndDate: true,
  venue: true,
  city: true,
  state: true,
  guestCount: true,
  budget: true,
  functions: true,
  isComplete: true
});
var insertEventSchema = createInsertSchema(events).pick({
  name: true,
  description: true,
  date: true,
  time: true,
  location: true,
  icon: true,
  color: true,
  guestCount: true,
  weddingProfileId: true
});
var insertGuestSchema = createInsertSchema(guests).pick({
  name: true,
  email: true,
  phone: true,
  side: true,
  rsvpStatus: true,
  weddingProfileId: true
});
var insertTaskSchema = createInsertSchema(tasks).pick({
  title: true,
  description: true,
  category: true,
  status: true,
  assignedTo: true,
  dueDate: true,
  eventId: true,
  weddingProfileId: true
}).extend({
  weddingProfileId: z.number().optional()
});
var insertBudgetItemSchema = createInsertSchema(budgetItems).pick({
  category: true,
  vendor: true,
  description: true,
  estimatedAmount: true,
  actualAmount: true,
  paidAmount: true,
  status: true,
  paidBy: true,
  eventId: true,
  weddingProfileId: true
}).extend({
  weddingProfileId: z.number().optional()
});
var insertVendorSchema = createInsertSchema(vendors).pick({
  name: true,
  category: true,
  contact: true,
  email: true,
  phone: true,
  address: true,
  website: true,
  contractUrl: true,
  notes: true,
  totalPrice: true,
  securityDeposit: true,
  paidBy: true,
  weddingProfileId: true
}).extend({
  weddingProfileId: z.number().optional()
});

// server/db.ts
import pg from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
var { Pool } = pg;
var pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});
var db = drizzle(pool, { schema: schema_exports });

// server/storage.ts
import { eq } from "drizzle-orm";
var DatabaseStorage = class {
  async getUser(id) {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || void 0;
  }
  async getUserByUsername(username) {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || void 0;
  }
  async createUser(insertUser) {
    const [user] = await db.insert(users).values({
      ...insertUser,
      weddingProfileId: insertUser.weddingProfileId || null
    }).returning();
    return user;
  }
  async updateUser(id, userUpdate) {
    const [user] = await db.update(users).set(userUpdate).where(eq(users.id, id)).returning();
    return user || void 0;
  }
  async getEvents(weddingProfileId) {
    if (weddingProfileId) {
      return await db.select().from(events).where(eq(events.weddingProfileId, weddingProfileId));
    }
    return await db.select().from(events);
  }
  async getEvent(id) {
    const [event] = await db.select().from(events).where(eq(events.id, id));
    return event || void 0;
  }
  async createEvent(insertEvent) {
    const [event] = await db.insert(events).values(insertEvent).returning();
    return event;
  }
  async updateEvent(id, eventUpdate) {
    const [event] = await db.update(events).set(eventUpdate).where(eq(events.id, id)).returning();
    return event || void 0;
  }
  async deleteEvent(id) {
    const result = await db.delete(events).where(eq(events.id, id));
    return (result.rowCount || 0) > 0;
  }
  async getGuests(weddingProfileId) {
    if (weddingProfileId) {
      return await db.select().from(guests).where(eq(guests.weddingProfileId, weddingProfileId));
    }
    return await db.select().from(guests);
  }
  async getGuest(id) {
    const [guest] = await db.select().from(guests).where(eq(guests.id, id));
    return guest || void 0;
  }
  async createGuest(insertGuest) {
    const [guest] = await db.insert(guests).values({
      ...insertGuest,
      email: insertGuest.email || null,
      phone: insertGuest.phone || null,
      rsvpStatus: insertGuest.rsvpStatus || null
    }).returning();
    return guest;
  }
  async updateGuest(id, guestUpdate) {
    const [guest] = await db.update(guests).set(guestUpdate).where(eq(guests.id, id)).returning();
    return guest || void 0;
  }
  async deleteGuest(id) {
    const result = await db.delete(guests).where(eq(guests.id, id));
    return (result.rowCount || 0) > 0;
  }
  async getTasks(weddingProfileId) {
    if (weddingProfileId) {
      return await db.select().from(tasks).where(eq(tasks.weddingProfileId, weddingProfileId));
    }
    return await db.select().from(tasks);
  }
  async getTask(id) {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task || void 0;
  }
  async createTask(insertTask) {
    const [task] = await db.insert(tasks).values(insertTask).returning();
    return task;
  }
  async updateTask(id, taskUpdate) {
    const [task] = await db.update(tasks).set(taskUpdate).where(eq(tasks.id, id)).returning();
    return task || void 0;
  }
  async deleteTask(id) {
    const result = await db.delete(tasks).where(eq(tasks.id, id));
    return (result.rowCount || 0) > 0;
  }
  async getBudgetItems(weddingProfileId) {
    if (weddingProfileId) {
      return await db.select().from(budgetItems).where(eq(budgetItems.weddingProfileId, weddingProfileId));
    }
    return await db.select().from(budgetItems);
  }
  async getBudgetItem(id) {
    const [budgetItem] = await db.select().from(budgetItems).where(eq(budgetItems.id, id));
    return budgetItem || void 0;
  }
  async createBudgetItem(insertBudgetItem) {
    const [budgetItem] = await db.insert(budgetItems).values(insertBudgetItem).returning();
    return budgetItem;
  }
  async updateBudgetItem(id, budgetItemUpdate) {
    const [budgetItem] = await db.update(budgetItems).set(budgetItemUpdate).where(eq(budgetItems.id, id)).returning();
    return budgetItem || void 0;
  }
  async deleteBudgetItem(id) {
    const result = await db.delete(budgetItems).where(eq(budgetItems.id, id));
    return (result.rowCount || 0) > 0;
  }
  async getVendors(weddingProfileId) {
    if (weddingProfileId) {
      return await db.select().from(vendors).where(eq(vendors.weddingProfileId, weddingProfileId));
    }
    return await db.select().from(vendors);
  }
  async getVendor(id) {
    const [vendor] = await db.select().from(vendors).where(eq(vendors.id, id));
    return vendor || void 0;
  }
  async createVendor(insertVendor) {
    const [vendor] = await db.insert(vendors).values(insertVendor).returning();
    return vendor;
  }
  async updateVendor(id, vendorUpdate) {
    const [vendor] = await db.update(vendors).set(vendorUpdate).where(eq(vendors.id, id)).returning();
    return vendor || void 0;
  }
  async deleteVendor(id) {
    const result = await db.delete(vendors).where(eq(vendors.id, id));
    return (result.rowCount || 0) > 0;
  }
  async getWeddingProfile(id) {
    const [profile] = await db.select().from(weddingProfiles).where(eq(weddingProfiles.id, id));
    return profile || void 0;
  }
  async getWeddingProfiles() {
    return await db.select().from(weddingProfiles);
  }
  async createWeddingProfile(insertProfile) {
    const [profile] = await db.insert(weddingProfiles).values(insertProfile).returning();
    if (profile) {
      const brideLastName = this.extractLastName(insertProfile.brideName);
      const groomLastName = this.extractLastName(insertProfile.groomName);
      await this.createGuest({
        name: insertProfile.brideName,
        email: "",
        phone: "",
        side: brideLastName,
        rsvpStatus: "confirmed",
        weddingProfileId: profile.id
      });
      await this.createGuest({
        name: insertProfile.groomName,
        email: "",
        phone: "",
        side: groomLastName,
        rsvpStatus: "confirmed",
        weddingProfileId: profile.id
      });
    }
    return profile;
  }
  extractLastName(fullName) {
    const nameParts = fullName.trim().split(" ");
    return nameParts.length > 1 ? nameParts[nameParts.length - 1] : fullName;
  }
  async updateWeddingProfile(id, profileUpdate) {
    const [profile] = await db.update(weddingProfiles).set(profileUpdate).where(eq(weddingProfiles.id, id)).returning();
    return profile || void 0;
  }
};
var storage = new DatabaseStorage();

// server/routes.ts
import bcrypt from "bcryptjs";
async function registerRoutes(app2) {
  app2.get("/api/clear-rate-limit", (req, res) => {
    res.json({ message: "Rate limit cleared" });
  });
  app2.get("/api/test", (req, res) => {
    res.json({ message: "API is working", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app2.post("/api/auth/login", async (req, res) => {
    try {
      console.log("Login attempt received:", { username: req.body.username });
      const { username, password } = req.body;
      const user = await storage.getUserByUsername(username);
      if (!user || !await bcrypt.compare(password, user.password)) {
        console.log("Login failed: invalid credentials for username:", username);
        return res.status(401).json({ error: "Invalid credentials" });
      }
      req.session.userId = user.id;
      console.log("Login successful for user:", user.id);
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Login failed" });
    }
  });
  app2.post("/api/auth/register", async (req, res) => {
    try {
      console.log("Registration attempt received:", { username: req.body.username, name: req.body.name });
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        console.log("Registration failed: username already exists:", userData.username);
        return res.status(400).json({ error: "Username already exists" });
      }
      const hashedPassword = await bcrypt.hash(userData.password, 12);
      const userWithHashedPassword = { ...userData, password: hashedPassword };
      const user = await storage.createUser(userWithHashedPassword);
      req.session.userId = user.id;
      console.log("Registration successful for user:", user.id);
      const { password: _, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ error: "Registration failed" });
    }
  });
  app2.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Logout failed" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });
  app2.get("/api/auth/me", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        req.session.destroy(() => {
        });
        return res.status(401).json({ error: "Invalid session" });
      }
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Session check error:", error);
      res.status(500).json({ error: "Session check failed" });
    }
  });
  app2.post("/api/wedding-profile", authenticateUser, async (req, res) => {
    try {
      const profileData = insertWeddingProfileSchema.parse(req.body);
      const weddingProfile = await storage.createWeddingProfile(profileData);
      await storage.updateUser(req.user.id, { weddingProfileId: weddingProfile.id });
      res.status(201).json(weddingProfile);
    } catch (error) {
      console.error("Wedding profile creation error:", error);
      res.status(400).json({ error: "Failed to create wedding profile" });
    }
  });
  app2.get("/api/wedding-profile", authenticateUser, async (req, res) => {
    try {
      const user = req.user;
      if (!user.weddingProfileId) {
        return res.status(404).json({ error: "No wedding profile found" });
      }
      const profile = await storage.getWeddingProfile(user.weddingProfileId);
      if (!profile) {
        return res.status(404).json({ error: "Wedding profile not found" });
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch wedding profile" });
    }
  });
  app2.get("/api/wedding-profile/:id", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const profile = await storage.getWeddingProfile(id);
      if (!profile) {
        return res.status(404).json({ error: "Wedding profile not found" });
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch wedding profile" });
    }
  });
  app2.get("/api/events", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const weddingProfileId = req.user.weddingProfileId;
      if (!weddingProfileId) {
        return res.status(404).json({ error: "No wedding profile found" });
      }
      const events2 = await storage.getEvents(weddingProfileId);
      const sortedEvents = events2.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      res.json(sortedEvents);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch events" });
    }
  });
  app2.post("/api/events", authenticateUser, authorizeUser, async (req, res) => {
    try {
      console.log("Received event data:", req.body);
      const eventData = insertEventSchema.parse({
        ...req.body,
        weddingProfileId: req.user.weddingProfileId
      });
      console.log("Parsed event data:", eventData);
      const event = await storage.createEvent(eventData);
      res.status(201).json(event);
    } catch (error) {
      console.error("Event creation error:", error);
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      res.status(400).json({ error: "Invalid event data", details: errorMessage });
    }
  });
  app2.put("/api/events/:id", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const eventData = req.body;
      const event = await storage.updateEvent(id, eventData);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.json(event);
    } catch (error) {
      res.status(400).json({ error: "Invalid event data" });
    }
  });
  app2.delete("/api/events/:id", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteEvent(id);
      if (!success) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete event" });
    }
  });
  app2.get("/api/guests", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const weddingProfileId = req.user.weddingProfileId;
      if (!weddingProfileId) {
        return res.status(404).json({ error: "No wedding profile found" });
      }
      const guests2 = await storage.getGuests(weddingProfileId);
      res.json(guests2);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch guests" });
    }
  });
  app2.post("/api/guests", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const guestData = insertGuestSchema.parse({
        ...req.body,
        weddingProfileId: req.user.weddingProfileId
      });
      const guest = await storage.createGuest(guestData);
      res.status(201).json(guest);
    } catch (error) {
      res.status(400).json({ error: "Invalid guest data" });
    }
  });
  app2.put("/api/guests/:id", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const guestData = req.body;
      const guest = await storage.updateGuest(id, guestData);
      if (!guest) {
        return res.status(404).json({ error: "Guest not found" });
      }
      res.json(guest);
    } catch (error) {
      res.status(400).json({ error: "Invalid guest data" });
    }
  });
  app2.delete("/api/guests/:id", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteGuest(id);
      if (!success) {
        return res.status(404).json({ error: "Guest not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete guest" });
    }
  });
  app2.get("/api/tasks", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const weddingProfileId = req.user.weddingProfileId;
      if (!weddingProfileId) {
        return res.status(404).json({ error: "No wedding profile found" });
      }
      const tasks2 = await storage.getTasks(weddingProfileId);
      res.json(tasks2);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch tasks" });
    }
  });
  app2.post("/api/tasks", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse({
        ...req.body,
        weddingProfileId: req.user.weddingProfileId
      });
      const task = await storage.createTask(taskData);
      res.status(201).json(task);
    } catch (error) {
      res.status(400).json({ error: "Invalid task data" });
    }
  });
  app2.put("/api/tasks/:id", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const taskData = req.body;
      const task = await storage.updateTask(id, taskData);
      if (!task) {
        return res.status(404).json({ error: "Task not found" });
      }
      res.json(task);
    } catch (error) {
      res.status(400).json({ error: "Invalid task data" });
    }
  });
  app2.delete("/api/tasks/:id", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteTask(id);
      if (!success) {
        return res.status(404).json({ error: "Task not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete task" });
    }
  });
  app2.get("/api/export/guests", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const weddingProfileId = req.user.weddingProfileId;
      if (!weddingProfileId) {
        return res.status(404).json({ error: "No wedding profile found" });
      }
      const guests2 = await storage.getGuests(weddingProfileId);
      const csv = [
        "Name,Email,Phone,Side,RSVP Status",
        ...guests2.map(
          (guest) => `"${guest.name}","${guest.email || ""}","${guest.phone || ""}","${guest.side}","${guest.rsvpStatus || "pending"}"`
        )
      ].join("\n");
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=guests.csv");
      res.send(csv);
    } catch (error) {
      res.status(500).json({ error: "Failed to export guests" });
    }
  });
  app2.get("/api/export/tasks", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const weddingProfileId = req.user.weddingProfileId;
      if (!weddingProfileId) {
        return res.status(404).json({ error: "No wedding profile found" });
      }
      const tasks2 = await storage.getTasks(weddingProfileId);
      const csv = [
        "Title,Description,Category,Status,Assigned To,Due Date",
        ...tasks2.map(
          (task) => `"${task.title}","${task.description || ""}","${task.category}","${task.status}","${task.assignedTo}","${task.dueDate || ""}"`
        )
      ].join("\n");
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=tasks.csv");
      res.send(csv);
    } catch (error) {
      res.status(500).json({ error: "Failed to export tasks" });
    }
  });
  app2.get("/api/budget", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const weddingProfileId = req.user.weddingProfileId;
      if (!weddingProfileId) {
        return res.status(404).json({ error: "No wedding profile found" });
      }
      const budgetItems2 = await storage.getBudgetItems(weddingProfileId);
      res.json(budgetItems2);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch budget items" });
    }
  });
  app2.post("/api/budget", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const budgetData = insertBudgetItemSchema.parse({
        ...req.body,
        weddingProfileId: req.user.weddingProfileId
      });
      const budgetItem = await storage.createBudgetItem(budgetData);
      res.status(201).json(budgetItem);
    } catch (error) {
      res.status(400).json({ error: "Invalid budget data" });
    }
  });
  app2.put("/api/budget/:id", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const budgetData = req.body;
      const budgetItem = await storage.updateBudgetItem(id, budgetData);
      if (!budgetItem) {
        return res.status(404).json({ error: "Budget item not found" });
      }
      res.json(budgetItem);
    } catch (error) {
      res.status(400).json({ error: "Invalid budget data" });
    }
  });
  app2.delete("/api/budget/:id", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteBudgetItem(id);
      if (!success) {
        return res.status(404).json({ error: "Budget item not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete budget item" });
    }
  });
  app2.get("/api/vendors", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const weddingProfileId = req.user.weddingProfileId;
      if (!weddingProfileId) {
        return res.status(404).json({ error: "No wedding profile found" });
      }
      const vendors2 = await storage.getVendors(weddingProfileId);
      res.json(vendors2);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch vendors" });
    }
  });
  app2.post("/api/vendors", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const vendorData = insertVendorSchema.parse({
        ...req.body,
        weddingProfileId: req.user.weddingProfileId
      });
      const vendor = await storage.createVendor(vendorData);
      res.status(201).json(vendor);
    } catch (error) {
      res.status(400).json({ error: "Invalid vendor data" });
    }
  });
  app2.put("/api/vendors/:id", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const vendorData = req.body;
      const vendor = await storage.updateVendor(id, vendorData);
      if (!vendor) {
        return res.status(404).json({ error: "Vendor not found" });
      }
      res.json(vendor);
    } catch (error) {
      res.status(400).json({ error: "Invalid vendor data" });
    }
  });
  app2.delete("/api/vendors/:id", authenticateUser, authorizeUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteVendor(id);
      if (!success) {
        return res.status(404).json({ error: "Vendor not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete vendor" });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs from "fs";
import path2 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
var vite_config_default = defineConfig({
  plugins: [
    react({
      jsxRuntime: "automatic",
      jsxImportSource: "react"
    })
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    fs: {
      strict: true,
      deny: ["**/.*"]
    },
    proxy: {
      "/api": {
        target: "http://localhost:5000",
        changeOrigin: true,
        secure: false
      }
    }
  },
  define: {
    "process.env.NODE_ENV": '"development"'
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}

// server/index.ts
import { fileURLToPath } from "url";
var __filename = fileURLToPath(import.meta.url);
var __dirname = path3.dirname(__filename);
var app = express2();
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
      imgSrc: ["'self'", "data:", "https:"]
    }
  }
}));
var limiter = rateLimit({
  windowMs: 15 * 60 * 1e3,
  max: 1e3,
  message: "Too many requests from this IP, please try again later."
});
app.use(limiter);
app.use(cors({
  origin: process.env.NODE_ENV === "production" ? ["https://wedding-planner-hjgegeadbnaqfkge.canadacentral-01.azurewebsites.net", "https://wedding-planner-hjgegeadbnaqfkge.canadacentral-01.azurewebsites.net/"] : ["http://localhost:5000", "http://localhost:5173"],
  credentials: true,
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));
app.use(session({
  secret: process.env.SESSION_SECRET || "fallback-secret-key",
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === "production" && process.env.HTTPS === "true",
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1e3,
    sameSite: process.env.NODE_ENV === "production" ? "none" : "lax"
  },
  name: "weddingwizard.sid"
}));
app.use(express2.json({ limit: "10mb" }));
app.use(express2.urlencoded({ extended: true, limit: "10mb" }));
var uploadsDir = path3.join(process.cwd(), "server", "uploads");
if (!fs2.existsSync(uploadsDir)) fs2.mkdirSync(uploadsDir, { recursive: true });
var storageConfig = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + "-" + uniqueSuffix + path3.extname(file.originalname));
  }
});
var upload = multer({
  storage: storageConfig,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
    allowedTypes.includes(file.mimetype) ? cb(null, true) : cb(new Error("Only PDF, DOC, and DOCX files are allowed"));
  }
});
var authenticateUser = async (req, res, next) => {
  try {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Authentication required" });
    }
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      req.session.destroy(() => {
      });
      return res.status(401).json({ error: "Invalid session" });
    }
    req.user = user;
    next();
  } catch (error) {
    console.error("Authentication error:", error);
    res.status(500).json({ error: "Authentication failed" });
  }
};
var authorizeUser = (req, res, next) => {
  try {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Authentication required" });
    }
    const requestedWeddingProfileId = req.query.weddingProfileId || req.body.weddingProfileId || req.params.weddingProfileId;
    if (requestedWeddingProfileId && user.weddingProfileId !== parseInt(requestedWeddingProfileId)) {
      return res.status(403).json({ error: "Access denied" });
    }
    next();
  } catch (error) {
    console.error("Authorization error:", error);
    res.status(403).json({ error: "Access denied" });
  }
};
app.use((req, res, next) => {
  const start = Date.now();
  console.log(`Incoming request: ${req.method} ${req.path}`);
  const originalJson = res.json;
  res.json = function(body, ...args) {
    const duration = Date.now() - start;
    log(`${req.method} ${req.path} ${res.statusCode} in ${duration}ms`);
    return originalJson.apply(res, [body, ...args]);
  };
  next();
});
(async () => {
  app.post("/api/upload-contract", authenticateUser, upload.single("contract"), (req, res) => {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });
    res.json({
      filename: req.file.filename,
      originalName: req.file.originalname,
      size: req.file.size
    });
  });
  app.get("/api/download-contract/:filename", authenticateUser, (req, res) => {
    const filePath = path3.join(uploadsDir, req.params.filename);
    if (!fs2.existsSync(filePath)) return res.status(404).json({ error: "File not found" });
    res.download(filePath, req.params.filename.split("-").slice(2).join("-"));
  });
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || 500;
    res.status(status).json({ message: err.message || "Internal Server Error" });
    throw err;
  });
  app.use("/api/*", (req, res) => {
    res.status(404).json({ error: "API endpoint not found" });
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    const distPath = path3.join(__dirname, "../dist/public");
    app.use((req, res, next) => {
      if (req.path.startsWith("/api/")) {
        return next();
      }
      express2.static(distPath)(req, res, next);
    });
    app.get("*", (req, res, next) => {
      if (req.path.startsWith("/api/")) {
        return next();
      }
      res.sendFile(path3.join(distPath, "index.html"));
    });
  }
  const port = process.env.PORT ? parseInt(process.env.PORT) : 5e3;
  server.listen({ port, host: "0.0.0.0" }, () => {
    log(`\u2705 Server running on port ${port}`);
  });
})();
app.get("/health", (_req, res) => {
  res.send("\u2705 Server is alive");
});
export {
  authenticateUser,
  authorizeUser
};
